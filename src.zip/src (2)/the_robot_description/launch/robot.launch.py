import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.substitutions import Command, PathJoinSubstitution
from launch.actions import DeclareLaunchArgument

def generate_launch_description():
    urdf_path = PathJoinSubstitution([
        get_package_share_directory('the_robot_description'),
        'urdf',
        'robot.xacro'
    ])
    rviz_config_path = PathJoinSubstitution([
        get_package_share_directory('the_robot_description'),
        'rviz',
        'urdf_car.rviz'
    ])
    return LaunchDescription([
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            parameters=[{'robot_description': Command(['xacro ', urdf_path])}]
        ),
        Node(
            package='joint_state_publisher_gui',
            executable='joint_state_publisher_gui'
        ),
        Node(
            package='rviz2',
            executable='rviz2',
            output='screen',
            arguments=['-d', rviz_config_path]
        ),
    ])
